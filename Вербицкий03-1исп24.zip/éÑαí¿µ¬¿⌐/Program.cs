using Microsoft.Data.SqlClient;

var app = WebApplication.CreateBuilder(args).Build();

string cs = @"Server=DESKTOP-VNNK9U7\SQLEXPRESS;Database=Verbizky;Trusted_Connection=True;TrustServerCertificate=True;";

app.MapGet("/api/notes", () =>
{
    try
    {
        var list = new List<object>();
        using var conn = new SqlConnection(cs);
        conn.Open();

        using var cmd = new SqlCommand(
            @"SELECT n.id, n.title, n.content, u.login, n.Created_Date
              FROM Note n JOIN Users u ON n.id_user = u.id
              ORDER BY n.id", conn);

        using var r = cmd.ExecuteReader();
        while (r.Read())
            list.Add(new
            {
                id = r.GetInt32(0),
                title_user = $"{r.GetString(1)} - {r.GetString(3)}",
                content = r.IsDBNull(2) ? null : r.GetString(2),
                formatted_date = r.GetDateTime(4).ToString("dd.MM.yyyy")
            });

        return Results.Json(list, statusCode: 200);
    }
    catch (Exception e)
    {
        return Results.Json(new { error = e.Message }, statusCode: 500);
    }
});

app.Run("http://0.0.0.0:5000");